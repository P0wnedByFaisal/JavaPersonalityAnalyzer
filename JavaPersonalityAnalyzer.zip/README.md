
# Java Personality Analyzer

This is a simple Java-based project that uses OpenCV to analyze facial expressions from a video file. Based on the number of detected faces in the first 100 frames, it provides a basic personality interpretation.

## 🧠 Features

- Loads a video (`input.mp4`)
- Extracts the first 100 frames
- Detects faces using Haar Cascade
- Saves frames with detected faces
- Outputs a personality assessment:
  - "Friendly and outgoing"
  - "Calm and balanced"
  - "Serious or introverted"

## 📁 Project Structure

```
JavaPersonalityAnalyzer/
├── src/
│   └── Analyzer.java
├── frames/                            # Output folder for detected face frames
├── input.mp4                          # Add your input video here
├── haarcascade_frontalface_default.xml # Haar face detector (download required)
└── README.md
```

## 🧰 Requirements

- Java (JDK 8+)
- [OpenCV for Java](https://opencv.org/releases/)
- NetBeans or any Java IDE

## ⚙️ How to Run

1. Install OpenCV and add the `.jar` and native `.dll/.so` to your project build path.
2. Place your `input.mp4` video in the project root.
3. Download `haarcascade_frontalface_default.xml` from [OpenCV GitHub](https://github.com/opencv/opencv/blob/master/data/haarcascades/haarcascade_frontalface_default.xml).
4. Run the `Analyzer` class.

## ✅ Notes

- This is a basic demonstration for educational purposes.
- Face detection is done using classical Haar cascades.
- You can enhance it further with smile detection, emotion classification, or deep learning.

## 📄 License

MIT License
