
import org.opencv.core.*;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.objdetect.CascadeClassifier;
import org.opencv.videoio.VideoCapture;
import java.io.File;

public class Analyzer {
    public static void main(String[] args) {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);

        CascadeClassifier faceDetector = new CascadeClassifier("haarcascade_frontalface_default.xml");
        if (faceDetector.empty()) {
            System.out.println("Failed to load face detector.");
            return;
        }

        VideoCapture cap = new VideoCapture("input.mp4");
        if (!cap.isOpened()) {
            System.out.println("Failed to open video file.");
            return;
        }

        File dir = new File("frames");
        if (!dir.exists()) dir.mkdirs();

        Mat frame = new Mat();
        int count = 0;
        int faceCount = 0;

        while (cap.read(frame) && count < 100) {
            MatOfRect faces = new MatOfRect();
            faceDetector.detectMultiScale(frame, faces);

            if (faces.toArray().length > 0) {
                Imgcodecs.imwrite("frames/frame" + count + ".jpg", frame);
                System.out.println("Face detected in frame " + count);
                faceCount++;
            }

            count++;
        }

        cap.release();

        if (faceCount > 20) {
            System.out.println("Analysis: Friendly and outgoing personality.");
        } else if (faceCount > 5) {
            System.out.println("Analysis: Calm and balanced personality.");
        } else {
            System.out.println("Analysis: Serious or introverted personality.");
        }
    }
}
